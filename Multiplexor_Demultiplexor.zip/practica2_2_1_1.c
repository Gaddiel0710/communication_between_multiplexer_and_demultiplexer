#include <16f877a.h> //libreria del microcontrolador
#DEVICE adc=10 // resolucion de trabajo
#fuses xt, nowdt 
#use delay (clock = 4M) //reloj interno
#use rs232 (baud=9600, xmit=pin_C6, rcv=pin_C7, parity=N, bits=8) //libreria de trabajo para comunicacion rs232     
#use i2c(Master,Fast=100000, sda=PIN_C4, scl=PIN_C3,force_sw)  // librer�� para manejar la comunicaci�n I2C
#include "i2c_Flex_LCD.c" //driver para manejar la interface LCD I2C
#use standard_io (A,D,E) // declaracion de entradas en los pines A,B,E  


    
void main()
{
   while (TRUE) 
   { 
    while(true)
    {
      if(kbhit())
      {    
         if(regreso == 65)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_high(PIN_B7);        
         }
         else if(regreso == 66)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_high(PIN_B6);
            output_low(PIN_B7);         
         }
         else if(regreso == 67)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_high(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 68)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_high(PIN_B5);
            output_low(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 69)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_high(PIN_B5);
            output_low(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 70)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_high(PIN_B5);
            output_high(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 71)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_high(PIN_B5);
            output_high(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 72)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 73)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 74)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_low(PIN_B5);
            output_high(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 75)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_low(PIN_B5);
            output_high(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 76)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_high(PIN_B5);
            output_low(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 77)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_high(PIN_B5);
            output_low(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 78)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_high(PIN_B5);
            output_high(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 209)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_high(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 79)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_high(PIN_B4);
            output_high(PIN_B5);
            output_high(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 80)
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 'Q')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 'R')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_high(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 'S')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_high(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 'T')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_low(PIN_B4);
            output_high(PIN_B5);
            output_low(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 'U')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_low(PIN_B4);
            output_high(PIN_B5);
            output_low(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 'V')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_low(PIN_B4);
            output_high(PIN_B5);
            output_high(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 'W')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_low(PIN_B4);
            output_high(PIN_B5);
            output_high(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 'X')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_high(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == 'Y')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_high(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_high(PIN_B7);
         }
         else if(regreso == 'Z')
         {
            output_low(PIN_B0);
            output_high(PIN_B1);
            output_low(PIN_B2);
            output_high(PIN_B3);
            output_high(PIN_B4);
            output_low(PIN_B5);
            output_high(PIN_B6);
            output_low(PIN_B7);
         }
         else if(regreso == ' ')
         {
            output_low(PIN_B0);
            output_low(PIN_B1);
            output_high(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_low(PIN_B7);
         }
         else
         {
            output_low(PIN_B0);
            output_low(PIN_B1);
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
            output_low(PIN_B5);
            output_low(PIN_B6);
            output_low(PIN_B7);
         }
      }
      break;
      
      //en prueba
          //GENERAR EL CODIGO BINARIO   
    if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 0 && BT6 == 0 && BT7 == 0 && BT8==1){
      letra = 65;//A
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 0 && BT6 == 0 && BT7 == 1 && BT8==0){
      letra = 66;//B 
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 0 && BT6 == 0 && BT7 == 1 && BT8==1){
      letra = 67;//C
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 0 && BT6 == 1 && BT7 == 0 && BT8==0){
      letra = 68;   //D 
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 0 && BT6 == 1 && BT7 == 0 && BT8==1){
      letra = 69;//E
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 0 && BT6 == 1 && BT7 == 1 && BT8==0){
      letra = 70;//F
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 0 && BT6 == 1 && BT7 == 1 && BT8==1){
      letra = 71;//G
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 1 && BT6 == 0 && BT7 == 0 && BT8==0){
      letra = 72;//H
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 1 && BT6 == 0 && BT7 == 0 && BT8==1){
      letra = 73;//I
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 1 && BT6 == 0 && BT7 == 1 && BT8==0){
      letra = 74;//J
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 1 && BT6 == 0 && BT7 == 1 && BT8==1){
      letra = 75;//K
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 1 && BT6 == 1 && BT7 == 0 && BT8==0){
      letra = 76;//L
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 1 && BT6 == 1 && BT7 == 0 && BT8==1){
      letra = 77;//M
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 1 && BT6 == 1 && BT7 == 1 && BT8==0){
      letra = 78;//N
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 1 && BT4== 0 && BT5 == 1 && BT6 == 0 && BT7 == 0 && BT8==1){
      letra = 209;//�
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 0 && BT5 == 1 && BT6 == 1 && BT7 == 1 && BT8==1){
      letra = 79;//O
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 0 && BT6 == 0 && BT7 == 0 && BT8==0){
      letra = 80;//P
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 0 && BT6 == 0 && BT7 == 0 && BT8==1){
      letra = 81;//Q
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 0 && BT6 == 0 && BT7 == 1 && BT8==0){
      letra = 82;//R
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 0 && BT6 == 0 && BT7 == 1 && BT8==1){
      letra = 83;//S
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 0 && BT6 == 1 && BT7 == 0 && BT8==0){
      letra = 84;//T
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 0 && BT6 == 1 && BT7 == 0 && BT8==1){
      letra = 85;//U
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 0 && BT6 == 1 && BT7 == 1 && BT8==0){
      letra = 86;//V
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 0 && BT6 == 1 && BT7 == 1 && BT8==1){
      letra = 87;//W
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 1 && BT6 == 0 && BT7 == 0 && BT8==0){
      letra = 88;//X
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 1 && BT6 == 0 && BT7 == 0 && BT8==1){
      letra = 89;//Y   
    }else if(BT1 == 0 && BT2 == 1 && BT3 == 0 && BT4== 1 && BT5 == 1 && BT6 == 0 && BT7 == 1 && BT8==0){
      letra = 90;//Z
    }else if(BT1 == 0 && BT2 == 0 && BT3 == 1 && BT4== 0 && BT5 == 0 && BT6 == 0 && BT7 == 0 && BT8==0){
      letra = 32;//ESPACIO     
    }else{
      letra = 0;
    }
    if (SEND == 1) 
    {
      PUTC(letra);
      lcd_gotoxy(1,2);
      printf(lcd_putc,"Send= %c",letra);
      printf(lcd_putc," #= %d",letra);
      delay_ms(500);
    }
     //en prueba 
      
    }
    

    
  }
}  



